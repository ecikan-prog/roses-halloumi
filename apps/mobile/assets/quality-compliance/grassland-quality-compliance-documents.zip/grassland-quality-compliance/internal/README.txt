INTERNAL — DO NOT PUBLISH

Halloumi-Guidelines-Technical-Reference.pdf

Technical Halloumi suggested cheese-making guidelines supplied by Chr. Hansen. Keep this document out of the public Grassland Cheese website/document library.
