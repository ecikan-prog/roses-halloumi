GRASSLAND CHEESE — WEBSITE PHOTO ASSET INSTRUCTIONS
========================================================

These images were supplied during the Grassland Cheese website design process.

IMPORTANT:
- These are visual/reference assets for the first website build.
- The packaging image shows ROSE'S branding, so DO NOT present it as Grassland Cheese packaging.
- Several food images contain an "IMAGINED WITH AI" watermark. Treat them as inspiration/reference only, not final commercial photography.
- Do not invent product claims, prices, ingredients, or packaging details from these images.

REPOSITORY
----------
Website/customer app project:
apps/mobile

Current static asset folder:
apps/mobile/assets

UPLOAD
------
Upload the image files in this folder to:

apps/mobile/assets/grassland/

Suggested final paths:
apps/mobile/assets/grassland/01-halloumi-product-packaging-reference.jpeg
apps/mobile/assets/grassland/02-grilled-halloumi-dish.jpeg
apps/mobile/assets/grassland/03-halloumi-skewers-inspiration.jpeg
apps/mobile/assets/grassland/04-halloumi-figs-inspiration.jpeg
apps/mobile/assets/grassland/05-halloumi-bacon-inspiration.jpeg
apps/mobile/assets/grassland/06-halloumi-platter-inspiration.jpeg
apps/mobile/assets/grassland/07-halloumi-serving-inspiration.jpeg

HOW TO UPLOAD FROM IPAD
-----------------------
1. Download/extract this ZIP on the iPad.
2. Open the GitHub repository for the Grassland Cheese project.
3. Open:
   apps/mobile/assets
4. Create a folder named:
   grassland
5. Upload all seven image files into that folder.
6. Commit the changes to the main branch (or the branch Copilot is currently using).
7. Tell Copilot the files are now available.

COPILOT INSTRUCTION AFTER UPLOAD
--------------------------------
"The Grassland Cheese reference photos have been uploaded to
apps/mobile/assets/grassland/.

Use them only where appropriate for the landing-page design.
Do not use the ROSE'S packaging image as Grassland Cheese packaging.
Do not treat AI-watermarked images as final commercial photography.
Keep the product catalogue limited to Halloumi 1 kg, 500 g and 200 g."

FINAL PRODUCT PHOTOS
--------------------
When real Grassland Cheese packaging photos are available, replace the
placeholder/reference product imagery with those actual photos.
