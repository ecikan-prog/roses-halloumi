GRASSLAND CHEESE — QUALITY & COMPLIANCE DOCUMENTS

These documents are the source PDFs supplied for the Grassland Cheese / Rose's Dairy website.

PUBLIC WEBSITE DOCUMENTS

01-MPI-Animal-Products-Exporter-Registration.pdf
Official MPI Notice of Registration for AYYILDIZ Limited trading as Roses Dairy (Halloumi Cheese).
MPI ID: AEX000656.
Effective: 16 March 2026.
Expires: 16 March 2027.

02-Food-Safety-Quality-Audit-Certificate.pdf
Quality Auditing Specialists Limited Certificate of Audit for Ayyildiz Ltd, trading as Rose's Halloumi.
Audit date: 02/07/2025.
Certificate expiry: 02/01/2027.

03-Roses-Dairy-Halloumi-Product-Specification.pdf
Rose's Dairy Halloumi product specification containing product, storage, preparation, shelf-life, ingredient, allergen and nutrition information.

IMPORTANT

These PDFs should be presented as downloadable/viewable official documents. Do not rewrite or alter the certificates themselves.

The Halloumi technical guideline is kept separately under internal/ and should NOT be published on the public website.
